import React,{Component} from "react";
import { ImageBackground, StyleSheet, Modal, ActivityIndicator, FlatList,View,Text,Image, TouchableOpacity,Alert,ScrollView,SafeAreaView} from "react-native";
import API from '../services/api';


export default class TreatmentDetails extends Component
{

     constructor(props)
     {
         super(props);
         this.state ={
               solution:'',
               protocol:'',
               image:'',
               progress: false,
         };
     }



     componentDidMount()
     {
      const { navigation } = this.props;  
      this.setState({ category_id :navigation.getParam('disease_solution_id', 'NO-id')}); 
      console.log(navigation.getParam('disease_solution_id', 'NO-id')) ;
      this.treatmentdetails(navigation.getParam('disease_solution_id', 'NO-id'));
       
     }



    async treatmentdetails (text) {

      this.setState({ progress: true})
     
        var formdata = new FormData();
        
        formdata.append('disease_solution_id', text);
        console.log("test",text);
        var response = await API.postWithFormData('search-disease-sol', formdata);
        if (response.message == 'Success') {
          console.log(response.img_url+response.data.protocol_image);
          this.setState({
            solution: response.data.solutions, 
            protocol:response.data.protocol,
            image:response.img_url+response.data.protocol_image,
            progress: false
            
        });
          
        } else {
          this.setState({ progress: false})
          Alert.alert(response.status, response.message);
        }
    
      
      };


    
    render()
    {
        return(
            <ImageBackground style ={styles.container}
            source ={require('../Images/bg.jpg')}>
<SafeAreaView >

<TouchableOpacity style={{ marginLeft:23, marginTop: 25}}
                  onPress={() => this.props.navigation.goBack()}>
                <Image style={{resizeMode:'contain', width:30,height:30, tintColor: 'black'}} source = {require('../Images/arrow.png')}></Image>
                </TouchableOpacity>

               <View style={{ alignSelf: 'flex-end'}}>

<TouchableOpacity  onPress= {()=> this.props.navigation.navigate('Dashboard')}><Image style={{resizeMode:'contain',width:50,height:50,alignSelf:'flex-end',marginRight:20}} source = {require('../Images/logo.png')}></Image>
 </TouchableOpacity> 
</View>
        

<ScrollView >
            <View><Text style={{color:'black',marginTop:2,fontSize:25,marginLeft:10,fontWeight:'bold'}}>Treatment Details</Text></View>
           <View><Text style={{color:'black',padding:10,fontSize:18,fontWeight:'bold',alignSelf:"center"}}>
           {this.state.solution}
           </Text>
           <Text style={{color:'black',padding:10,fontSize:18,alignSelf:"center"}}>
           {this.state.protocol}
           </Text>
           </View>

            <Image style={{resizeMode:'contain',width:'60%',height:'50%',justifyContent:'center',alignSelf:'center'}} source={{uri: this.state.image}}/>
             </ScrollView>
             </SafeAreaView>

             <Modal
            transparent={true}
            animationType={'none'}
            visible={this.state.progress}
            onRequestClose={() => {console.log('close modal')}}>
            <View style={{
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'space-around',
        backgroundColor: '#00000040'
    }}>
                <View style={{
        backgroundColor: '#FFFFFF',
        height: 100,
        width: 100,
        borderRadius: 10,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    }}>
                    <ActivityIndicator color="#999999" size="large"
                        animating={this.state.progress} />
                        {/* <Text style={{color: 'black',fontSize:16, marginTop: 20, alignSelf: 'center'}}>Loading...</Text> */}
                </View>
            </View>
        </Modal>

            </ImageBackground>
        );
    }
}


var styles = StyleSheet.create({
    container: {
         flex: 1,
         width:null,
         height:null,
    },
    boxarea : {
        marginRight: 20,
        marginLeft: 20,
       
        height:'30%',
       backgroundColor: '#fff',
        borderRadius: 10,
        borderWidth: 1,
        marginTop:20,
        color:'back'
    },    
    Imagearea : {
        marginRight: 20,
        marginLeft: 20,
       
        height:'55%',
       backgroundColor: '#fff',
        borderRadius: 10,
        borderWidth: 1,
        marginTop:20,
        color:'back'

    }, 
    
    
    item: {
        backgroundColor: '#D3D3D3',
        marginVertical: 8,
        marginHorizontal: 16,
        height: '30%',
        marginRight: 40,
        marginLeft: 40,
        marginTop:20,
      },
      title: {
        fontSize: 12,
      },

})
