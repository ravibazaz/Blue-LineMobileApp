import React,{Component} from "react";
import {ImageBackground,FlatList,TextInput,Alert,StyleSheet,View,Text,Image, SafeAreaView, Modal, ActivityIndicator,} from 'react-native';
import { TouchableOpacity } from "react-native-gesture-handler";
import LinearGradient from "react-native-linear-gradient";
import API from '../services/api';
import ImageLoad from 'react-native-image-placeholder';

export default class ChartDetails extends Component
{

  constructor(props)
  {
      super(props);
      this.state ={
            details:[],
            solution:'',
            protocol:'',
            image:'',
            progress: false,
      };
  }


  componentDidMount()
     {
      const { navigation } = this.props;  
      this.setState({ category_id :navigation.getParam('chart_id', 'NO-id')}); 
      console.log(navigation.getParam('chart_id', 'NO-id')) ;
      this.chartdetails(navigation.getParam('chart_id', 'NO-id'));
       
     }


     async chartdetails (text) {
      this.setState({ progress: true})
      var formdata = new FormData();
      
      formdata.append('chart_id', text);
      console.log("test",text);
      var response = await API.postWithFormData('chart-protocol-list', formdata);
      if (response.message == 'Success') {
        this.setState({ progress: false})
        console.log(response.img_url+response.data.protocol_image);
        this.setState({
          details: [...response.data],
          image:response.img_url, 
          
      });
        
      } else {
        this.setState({ progress: false})
      Alert.alert(response.status, response.message);
      }
  
    
    };



   //handling onPress action  
   getListViewItem = (item) => {  
    Alert.alert(item.key);  
  } 
  renderlog =({item}) =>
  {
    return(
      <View style={{flex: 1}}>
      <TouchableOpacity style = {{ marginLeft:10,marginRight:10, marginBottom: 15}}  onPress ={() => this.props.navigation.navigate('FullImage',{Chart_image: this.state.image+item.protocol_img,})} >
            
                {/* <Text style={{fontSize:20,alignSelf:'flex-start',color:'black',fontWeight:'500',
            marginTop:14}}  onPress={this.getListViewItem.bind(this, item)}>{item.protocol_name}</Text>         */}
                <ImageLoad style={{ height:500,borderRadius:2,width: 300, justifyContent: 'center',    //  <-- you can use "center", "flex-start",
    resizeMode: "contain", alignSelf: 'center', 
}}
// placeholderSource={require('../Images/outline_image_black_48pt_3x.png')}
loadingStyle={{ size: 'large', color: '#07afd6' }} //color: '#07afd6'
// isShowActivity = {false}
source={{uri: this.state.image+item.protocol_img}}>
</ImageLoad> 
    </TouchableOpacity>
  
</View>


    );


  }


render()
{
   
    return(
       <ImageBackground style ={styles.container}
       source ={require('../Images/bg.jpg')}>
<SafeAreaView >



<TouchableOpacity style={{ marginLeft:23, marginTop: 25}}
                  onPress={() => this.props.navigation.goBack()}>
                <Image style={{resizeMode:'contain', width:30,height:30, tintColor: 'black'}} source = {require('../Images/arrow.png')}></Image>
                </TouchableOpacity>

<View style={{ alignSelf: 'flex-end'}}>

<TouchableOpacity  onPress= {()=> this.props.navigation.navigate('Dashboard')}><Image style={{resizeMode:'contain',width:50,height:50,alignSelf:'flex-end',marginRight:20}} source = {require('../Images/logo.png')}></Image>
 </TouchableOpacity> 
</View>

</SafeAreaView>
         <Text style={{padding:10,color:'black',fontSize:25,fontWeight:"bold", marginBottom: 5}}>Chart Name</Text>
        {/* <View style = {styles.item}><TextInput style ={{color:'black',marginTop:5,marginLeft:10}}>Search</TextInput></View> */}
        
        <FlatList
          data={this.state.details}
          renderItem ={this.renderlog}
          keyExtractor ={item => item.id}
          // ListFooterComponent={<View style={{height: 234}}/>}
          />
   
   <Modal
            transparent={true}
            animationType={'none'}
            visible={this.state.progress}
            onRequestClose={() => {console.log('close modal')}}>
            <View style={{
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'space-around',
        backgroundColor: '#00000040'
    }}>
                <View style={{
        backgroundColor: '#FFFFFF',
        height: 100,
        width: 100,
        borderRadius: 10,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    }}>
                    <ActivityIndicator color="#999999" size="large"
                        animating={this.state.progress} />
                        {/* <Text style={{color: 'black',fontSize:16, marginTop: 20, alignSelf: 'center'}}>Loading...</Text> */}
                </View>
            </View>
        </Modal>
          
       </ImageBackground>
    
    );
}

}

var styles = StyleSheet.create({

  container:{
    flex:1,
    width:null,
    height:null
  },
  boxarea:{
    marginRight:20,
    marginLeft:20,
    height:'80%',
    borderRadius:10,
    borderWidth:1
   },
    item: {
    backgroundColor: '#D3D3D3',
    marginVertical: 8,
    marginHorizontal: 16,
    height: 50,
    marginRight: 40,
    marginLeft: 40,
    marginTop:5,
  },

})