import React,{Component} from "react";
import {StyleSheet, Modal, ActivityIndicator, ImageBackground,Text,TouchableOpacity,FlatList,View,TextInput,Image,Alert, SafeAreaView} from 'react-native';
import LinearGradient from "react-native-linear-gradient";
import API from '../services/api';


export default class ChartList extends Component
{

  constructor(props)
  {
    super(props);
    this.state = {
      
      chart_name:'',
      chart_list:[],
      progress: false,

  };
  }

  
  //handling onPress action  
  getListViewItem = (item) => {  
    Alert.alert(item.key);  
  } 

  componentDidMount ()
  {
    this.setState({ progress: true})
   this.Chart_list();

  }



  Chart_list = async ()=> {
   
    var logs = {
      // user_id: user_id,
    };
    console.log(logs);
    var response = await API.post('chart-list', logs);
    if (response.message == 'Success') {
      console.log(response.data);
      this.setState({
        chart_list: [...response.data], });
        this.setState({ progress: false})
      
    } else {
      this.setState({ progress: false})
      Alert.alert(response.status, response.message);
    }

  
  };

   
  async Chart_search (text) {

    
    // this.setState({ progress: true})
    var formdata = new FormData();
    formdata.append('chart_name', text);
    console.log("test",text);
    var response = await API.postWithFormData('search-chart', formdata);
    if (response.message == 'Success') {
      console.log(response.data);
      this.setState({
        chart_list: [...response.data]});
      
    } else {
      // this.setState({ progress: false})
    }

  
  };



    render()
    {
        return(
            <ImageBackground style ={styles.container}
    source ={require('../Images/bg.jpg')}>
  <SafeAreaView >

  <TouchableOpacity style={{ marginLeft:23, marginTop: 25}}
                  onPress={() => this.props.navigation.goBack()}>
                <Image style={{resizeMode:'contain', width:30,height:30, tintColor: 'black'}} source = {require('../Images/arrow.png')}></Image>
                </TouchableOpacity>

  <View style={{ alignSelf: 'flex-end'}}>

<TouchableOpacity  onPress= {()=> this.props.navigation.navigate('Dashboard')}><Image style={{resizeMode:'contain',width:50,height:50,alignSelf:'flex-end',marginRight:20}} source = {require('../Images/logo.png')}></Image>
 </TouchableOpacity> 
</View>
</SafeAreaView >
   
  <View><Text style={{color:'black',fontSize:25,marginLeft:10,fontWeight:'bold'}}>Chart</Text></View>
   <View style = {styles.item}><TextInput style ={{color:'black',marginTop:10,marginLeft:10}}  
                placeholder='Search'
                placeholderTextColor={'grey'}
                // value = {this.state.search}
              
                // autoCapitalize = 'none'
                // keyboardType={this.state.search}
                
               onChangeText={text => this.Chart_search(text)}
               onClear={text => this.Chart_search()}
               ></TextInput>
               </View>

    

        
              
    <FlatList
       data={this.state.chart_list}

        renderItem={({item})=>  
           <View>
          <TouchableOpacity style = {{marginTop:10, marginBottom:10,marginLeft:15,marginRight:15}} onPress ={() => this.props.navigation.navigate('Chartdetails',{chart_id: item.id,})}>
                <LinearGradient start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={{height:90, borderRadius:10}}
                 colors={['#ffe9e6','#fffdd5','#f5ffee','#e9ebff']}>
                    <Text style={{fontSize:18,alignSelf:'center',color:'black',fontWeight:'900',padding:5,
                marginTop:7}}>{item.chart}</Text>        
        </LinearGradient> 
        </TouchableOpacity>
      
    </View>} 

        keyExtractor={item => item.id}
      />

<Modal
            transparent={true}
            animationType={'none'}
            visible={this.state.progress}
            onRequestClose={() => {console.log('close modal')}}>
            <View style={{
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'space-around',
        backgroundColor: '#00000040'
    }}>
                <View style={{
        backgroundColor: '#FFFFFF',
        height: 100,
        width: 100,
        borderRadius: 10,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    }}>
                    <ActivityIndicator color="#999999" size="large"
                        animating={this.state.progress} />
                        {/* <Text style={{color: 'black',fontSize:16, marginTop: 20, alignSelf: 'center'}}>Loading...</Text> */}
                </View>
            </View>
        </Modal>

    </ImageBackground>
  
);  
    }
  }

  var styles = StyleSheet.create({
    container: {
         flex: 1,
         width:null,
         height:null,
    },
    boxarea : {
        marginRight: 20,
        marginLeft: 20,
       
        height:'80%',
       backgroundColor: '#fff',
        borderRadius: 10,
        borderWidth: 1,
        marginTop:20,
        color:'back'

    },  item: {
        backgroundColor: '#D3D3D3',
        marginVertical: 8,
        marginHorizontal: 16,
        height: 50,
        marginRight: 20,
        marginLeft: 20,
        marginTop:20,
      },
      title: {
        fontSize: 12,
      },




})