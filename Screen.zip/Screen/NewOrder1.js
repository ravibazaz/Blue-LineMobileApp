import React,{Component, useState} from 'react';
import { View, Text, StyleSheet, FlatList, ScrollView, TouchableOpacity, Linking, SafeAreaView, TextInput, Image, Dimensions } from 'react-native'
import DropDownPicker from 'react-native-dropdown-picker';
import DatePicker from 'react-native-date-picker'


export default class Profile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      openHaulage: false,
      value0: '',
      valueHaulage: '',
      containerPurchaseString : '',
      cargoTypeString: '',
      AgreedPriceString: '',
      TotalCargoWeightString: '',
      DestinationPortString: '',
      DestinationCountryString: '',
      SiteContactNameString: '',
      SiteContactTelnoString: '',
      LoadingPostcodeString: '',
      LoadingAddressString: '',
      Delivery_Time_String: '',
      Delivery_Date_String: '',
      DeliveryAddressString: '',
      Collection_Date_String: '',
      Collection_Time_String: '',

      openDateTimePicker: false,
      modeDateTimePicker: 'time',
      flag: '',
      Loading_Time_String: '',
      Loading_Date_String: '',
      time: new Date(),
      date: new Date(),
      items: [
         {label1: '20ft General Purpose', value1: '1'},
         {label1: '40ft General Purpose', value1: '2'},
         {label1: '40ft High Cube', value1: '3'},
        {label1: 'Other', value1: '4'},
       ],
       itemsHaulage: [
        {label1: 'Sidelifter (lifted to ground): Wait & load', value1: '1'},
        {label1: 'Sidelifter (lifted to ground): Drop & Collect', value1: '2'},
        {label1: 'Standard (on trailer): Wait & load', value1: '3'},
        {label1: 'Standard (on trailer): Trailer Drop & Collect', value1: '4'},
        {label1: 'Standard (on trailer): Quay to Quay', value1: '5'},
        {label1: 'Other', value1: '6'}
      ],
      itemList:  [
         {a: 'London To Paris', b: '102',  c: '23.12.2022', d: 'Available Stock: 45'}, 
         {a: 'Manchester United to Paris', b: '107',  c: '24.12.2022', d: 'Available Stock: 100'},
         {a: 'India To Paris', b: '311',  c: '25.12.2022', d: 'Available Stock: 134'},
         {a: 'ALPS', b: '102',  c: '26.12.2022', d: 'Available Stock: 45'}, 
         {a: 'ALPS', b: '107',  c: '27.12.2022', d: 'Available Stock: 100'},
         {a: 'ALPS', b: '311',  c: '28.12.2022', d: 'Available Stock: 134'},
         {a: 'ALPS', b: '102',  c: '29.12.2022', d: 'Available Stock: 45'}, 
         {a: 'ALPS', b: '107',  c: '30.12.2022', d: 'Available Stock: 100'},
         {a: 'ALPS', b: '311',  c: '31.12.2022', d: 'Available Stock: 134'},
         {a: 'ALPS', b: '107',  c: '12.12.2022', d: 'Available Stock: 100'},
         ],
         

    };
    this.setValue = this.setValue.bind(this);
    this.setValueHaulage = this.setValueHaulage.bind(this);
  }

  setOpen= (open) => {

   this.setState({
     open
   });
 }

 setValue = (callback) => {

   console.log('set value isssss', callback)

   this.setState(state => ({
     value0: callback(state.value0)
   }));
 }

//  setItems = (callback) => {
//    console.log('set Items is', callback)
//    this.setState(state => ({
//      items: callback(state.items)
//    }));
//  }

 setOpenHaulage= (openHaulage) => {

   this.setState({
     openHaulage
   });
 }
 setValueHaulage = (callback) => {


  this.setState(state => ({
    valueHaulage: callback(state.valueHaulage),
  }));

  console.log('value is=>', this.state.valueHaulage)

}

openDateTimePicker = (mode, hideOrShow, flag) =>
{
  this.setState({
    modeDateTimePicker: mode,
    openDateTimePicker: hideOrShow,
    flag: flag
  })
}
onChangeDateTimePicker = (date, flag) =>
{
  

  if (flag == 'Loading_Time')
  {
    this.setState({
      openDateTimePicker: false,
      Loading_Time_String: String(date),
      
    })
  }
  else if(flag == 'Loading_Date')
  {
    this.setState({
      openDateTimePicker: false,
      Loading_Date_String: String(date),
      
    })
  }
  else if(flag == 'Delivery_Date')
  {
    this.setState({
      openDateTimePicker: false,
      Delivery_Date_String: String(date),
      
    })
  }
  else if(flag == 'Delivery_Time')
  {
    this.setState({
      openDateTimePicker: false,
      Delivery_Time_String: String(date),
      
    })
  }
  else if(flag == 'Collection_Date')
  {
    this.setState({
      openDateTimePicker: false,
      Collection_Date_String: String(date),
      
    })
  }
  else if(flag == 'Collection_Time')
  {
    this.setState({
      openDateTimePicker: false,
      Collection_Time_String: String(date),
      
    })
  }

}

  render() {

   const { open, value, items } = this.state;

    return (
      
      <View style={styles.container}>
<SafeAreaView>
        
          </SafeAreaView>
          <ScrollView nestedScrollEnabled={true} horizontal={false}>
          <Text style={{fontFamily: 'BebasNeueProMiddle', fontSize: 25, marginTop: 45, color: '#4387bb', marginLeft: 24, marginBottom: 8}}>New Booking Continued</Text>
          


          
          <View style={styles.mainView}>  

          <Text style={styles.textLabel
}>{'Container Size & Type'}</Text>

<DropDownPicker
containerProps={{
  height: this.state.open === true ? 240 : null,
  
}}
listMode="SCROLLVIEW"
        scrollViewProps={{
          nestedScrollEnabled: true,
  }}
dropDownContainerStyle={{
  backgroundColor: "#ecf6fa",
  fontFamily: 'BebasNeueProRegular',
}}
style={{
  borderColor: "#4387bb",
  borderWidth: 1,
  backgroundColor: 'transparent'
}}

placeholder=""
schema={{
  label: 'label1',
  value: 'value1'
}}
        open={this.state.open}
        value={this.state.value0}
        items={this.state.items}
        setOpen={this.setOpen}
        setValue={this.setValue}
        setItems={this.setItems}
      />

<Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Container Purchase'}</Text>

<TextInput
                    style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 43,
                      borderRadius: 8,
                      paddingLeft: 8
                    }}
                    placeholder=""
                    // ref ={ref => this.inputText1 = ref}
                    // editable={this.state.iseditablefname}
                    onChangeText={value => this.setState({
                      containerPurchaseString: value,
                    })}
                    value={this.state.containerPurchaseString}
                    keyboardType="default"></TextInput>


<Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Cargo Type'}</Text>

<TextInput
                    style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 120,
                      borderRadius: 8,
                      paddingLeft: 8
                    }}
                    placeholder="Type Here"
                    // ref ={ref => this.inputText1 = ref}
                    // editable={this.state.iseditablefname}
                    onChangeText={value => this.setState({
                      cargoTypeString: value,
                    })}
                    textAlignVertical={'top'}
                    numberOfLines = {5}
                    multiline = {true}
                    value={this.state.cargoTypeString}
                    keyboardType="default"></TextInput>
 
 <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Haulage Type'}</Text>

<DropDownPicker
containerProps={{
  // height: this.state.openHaulage === true ? 240 : null,
  
}}
listMode="SCROLLVIEW"
        scrollViewProps={{
          nestedScrollEnabled: true,
  }}
dropDownContainerStyle={{
  backgroundColor: "#ecf6fa"
}}
style={{
  borderColor: "#4387bb",
  borderWidth: 1,
  backgroundColor: 'transparent'
}}

placeholder=""
schema={{
  label: 'label1',
  value: 'value1'
}}
        open={this.state.openHaulage}
        value={this.state.valueHaulage}
        items={this.state.itemsHaulage}
        setOpen={this.setOpenHaulage}
        setValue={this.setValueHaulage}
        setItems={this.setItemsHaulage}
      />


      { (this.state.valueHaulage == '1' || this.state.valueHaulage == '3') && <View>

      <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Loading Date'}</Text>

<TouchableOpacity onPress ={() => this.openDateTimePicker('date', true, 'Loading_Date')}>
<Text style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 43,
                      borderRadius: 8,
                      paddingLeft: 8,
                      textAlignVertical: 'center'
                    }}>{this.state.Loading_Date_String}</Text>
</TouchableOpacity>

      <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Loading Time'}</Text>

<TouchableOpacity onPress ={() => this.openDateTimePicker('time', true, 'Loading_Time')}>
<Text style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 43,
                      borderRadius: 8,
                      paddingLeft: 8,
                      textAlignVertical: 'center'
                    }}>{this.state.Loading_Time_String}</Text>
</TouchableOpacity>

<Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Loading Address'}</Text>

<TextInput
                    style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 120,
                      borderRadius: 8,
                      paddingLeft: 8
                    }}
                    placeholder="Type here"
                    // ref ={ref => this.inputText1 = ref}
                    // editable={this.state.iseditablefname}
                    onChangeText={value => this.setState({
                      LoadingAddressString: value,
                    })}
                    textAlignVertical={'top'}
                    numberOfLines = {5}
                    multiline = {true}
                    value={this.state.LoadingAddressString}
                    keyboardType="default"></TextInput>

        </View>}


        { (this.state.valueHaulage == '2' || this.state.valueHaulage == '4') && <View>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Delivery Date'}</Text>

<TouchableOpacity onPress ={() => this.openDateTimePicker('date', true, 'Delivery_Date')}>
<Text style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8,
                textAlignVertical: 'center'
              }}>{this.state.Delivery_Date_String}</Text>
</TouchableOpacity>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Delivery Time'}</Text>

<TouchableOpacity onPress ={() => this.openDateTimePicker('time', true, 'Delivery_Time')}>
<Text style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8,
                textAlignVertical: 'center'
              }}>{this.state.Delivery_Time_String}</Text>
</TouchableOpacity>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Delivery Address'}</Text>

<TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 120,
                borderRadius: 8,
                paddingLeft: 8
              }}
              placeholder="Type here"
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                DeliveryAddressString : value,
              })}
              textAlignVertical={'top'}
              numberOfLines = {5}
              multiline = {true}
              value={this.state.DeliveryAddressString}
              keyboardType="default"></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Collection Date'}</Text>

<TouchableOpacity onPress ={() => this.openDateTimePicker('date', true, 'Collection_Date')}>
<Text style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8,
                textAlignVertical: 'center'
              }}>{this.state.Collection_Date_String}</Text>
</TouchableOpacity>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Collection Time'}</Text>

<TouchableOpacity onPress ={() => this.openDateTimePicker('time', true, 'Collection_Time')}>
<Text style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8,
                textAlignVertical: 'center'
              }}>{this.state.Collection_Time_String}</Text>
</TouchableOpacity>

  </View>}

  { (this.state.valueHaulage == '5') && <View>

  <TouchableOpacity style={{marginTop: 15, alignItems: 'center'}} onPress ={() => console.log('dsd')}>
<Text style={{
                // borderColor: '#4387bb',
                // borderWidth: 1,
                width: '100%',
                color: 'white',
                height: 90,
                borderRadius: 8,
                // paddingLeft: 8,
                textAlignVertical: 'center',
                backgroundColor: '#4387bb',
                fontFamily: 'BebasNeueProRegular',
                fontSize: 22,
                justifyContent: 'center',
                alignSelf: 'center'
              }}>{'You are arranging your own haulage'}</Text>
</TouchableOpacity>

  </View>}

  { (this.state.valueHaulage == '6') && <View>

  <TouchableOpacity style={{marginTop: 15}} onPress ={() => Linking.openURL(`tel:${'+44(0)1371879400'}`)}>
<Text style={{
                // borderColor: '#4387bb',
                // borderWidth: 1,
                width: '100%',
                color: 'white',
                height: 90,
                borderRadius: 8,
                paddingLeft: 8,
                textAlignVertical: 'center',
                backgroundColor: '#4387bb',
                fontFamily: 'BebasNeueProRegular',
                fontSize: 22
              }}>{'Please contact the Containerlift team on +44(0)1371879400'}</Text>
</TouchableOpacity>

  </View>}

  <Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Agreed Price $'}</Text>

<TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8
              }}
              placeholder=""
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                AgreedPriceString : value,
              })}
              value={this.state.AgreedPriceString}
              keyboardType='decimal-pad'></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Total Cargo Weight (Kg)'}</Text>

<TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8
              }}
              placeholder=""
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                TotalCargoWeightString : value,
              })}
              value={this.state.TotalCargoWeightString}
              keyboardType='decimal-pad'></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Destination Port'}</Text>

<TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8
              }}
              placeholder=""
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                DestinationPortString : value,
              })}
              value={this.state.DestinationPortString}
              keyboardType='default'></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Destination Country'}</Text>

<TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8
              }}
              placeholder=""
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                DestinationCountryString : value,
              })}
              value={this.state.DestinationCountryString}
              keyboardType='default'></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}
}>{'Loading Time'}</Text>

<TouchableOpacity onPress ={() => this.openDateTimePicker('time', true, 'Loading_Time')}>
<Text style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 43,
                      borderRadius: 8,
                      paddingLeft: 8,
                      textAlignVertical: 'center'
                    }}>{this.state.Loading_Time_String}</Text>
</TouchableOpacity>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Site Contact Name'}</Text>

<TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8
              }}
              placeholder=""
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                SiteContactNameString : value,
              })}
              value={this.state.SiteContactNameString}
              keyboardType='default'></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Site Contact Tel Number'}</Text>

<TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8
              }}
              placeholder=""
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                SiteContactTelnoString : value,
              })}
              value={this.state.SiteContactTelnoString}
              keyboardType='phone-pad'></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Loading Address'}</Text>

<TextInput
                    style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 120,
                      borderRadius: 8,
                      paddingLeft: 8
                    }}
                    placeholder="Type here"
                    // ref ={ref => this.inputText1 = ref}
                    // editable={this.state.iseditablefname}
                    onChangeText={value => this.setState({
                      LoadingAddressString: value,
                    })}
                    textAlignVertical={'top'}
                    numberOfLines = {5}
                    multiline = {true}
                    value={this.state.LoadingAddressString}
                    keyboardType="default"></TextInput>

<Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey', marginTop: 15
}}>{'Loading Postcode'}</Text>

<TextInput
                    style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '100%',
                      color: 'black',
                      height: 43,
                      borderRadius: 8,
                      paddingLeft: 8
                    }}
                    placeholder=""
                    // ref ={ref => this.inputText1 = ref}
                    // editable={this.state.iseditablefname}
                    onChangeText={value => this.setState({
                      LoadingPostcodeString: value,
                    })}
                    value={this.state.LoadingPostcodeString}
                    keyboardType="default"></TextInput>

        <View style={{height: 100}}></View>
        
</View>
       
          

          {/* <FlatList
     keyboardDismissMode="none"
      keyboardShouldPersistTaps='handled'
      style={{
        marginTop: 6,
        marginBottom: 0
      }}
      
                        data={this.state.itemList}
                        renderItem={this.renderHorizontalItem}
                        keyExtractor={(item, index) => index}
                    />  */}

{/* { this.state.HaulageType != '' && <TouchableOpacity onPress ={() => console.log('selected value=> ', this.state.value0)} style={{margin: 13, flexDirection: 'row', justifyContent: 'flex-end',
alignItems: 'flex-end'}}>
<Text style={{fontSize: 23, justifyContent: 'center',  color: '#4387bb'}}>Continue</Text>
<Image style={{ height: 30, width: 30,resizeMode: 'contain', marginRight: 33, tintColor: '#4387bb'}}
                source={require('../Images/outline_arrow_right_alt_black_48.png')}></Image>
</TouchableOpacity> } */}



{/* <DropDownPicker
placeholder="Select category"
        open={this.state.open}
        value={this.state.value}
        items={this.state.items}
        setOpen={this.setOpen}
        setValue={this.setValue}
        setItems={this.setItems}
      />

<DropDownPicker
        open={this.state.open1}
        value={this.state.value1}
        items={this.state.items1}
        setOpen={this.setOpen1}
        setValue={this.setValue1}
        setItems={this.setItems1}
      /> */}

{/* outline_arrow_right_alt_black_48.png */}

          </ScrollView>

          <DatePicker
        modal
        mode={this.state.modeDateTimePicker}
        open={this.state.openDateTimePicker}
        date={this.state.date}
        onConfirm={(date) => this.onChangeDateTimePicker(date, this.state.flag)
        }
        onCancel={() => {
         this.setState({
            openopenDateTimePicker: false,
      
          });
        }}
      />
          <View style={styles.footer}>
      <View style={{flexDirection:'row', alignItems: 'center', justifyContent: 'center'}}>
            <View style={{flex:1, maxWidth: 414, backgroundColor: null, flexDirection:'row', justifyContent:'space-between'}}>
              
            <TouchableOpacity onPress ={() => this.props.navigation.navigate('LoginPage')}>
            <View style={{ marginLeft: 0, width: Dimensions.get('window').width/3, marginTop: 0, height: 80, backgroundColor: 'null'}}>
            <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'flex-start', marginStart: 18}}>
            <Image style={{ height: 30, width: 30,resizeMode: 'contain', }}
                source={require('../Images/Home.png')}></Image>
                <Text style={{fontSize: 11, marginTop: 5}}>Home</Text>
</View>

            
             </View>
             </TouchableOpacity>

            
                 

            <View style={{ marginLeft: 0, width: Dimensions.get('window').width/3, marginTop: 0, height: 80}}>
            <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'center'}}>
            <Image style={{ height: 30, width: 30,resizeMode: 'contain', }}
                source={require('../Images/plusicongrey.png')}></Image>
                <Text style={{fontSize: 11, marginTop: 5}}>New Booking</Text>
</View>
               </View>
            
            

               
                 
            <TouchableOpacity onPress ={() => this.props.navigation.navigate('ProfilePage')}>
            <View style={{ marginLeft: 0, width: Dimensions.get('window').width/3, marginTop: 0, height: 80}}>
            <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'flex-end', marginEnd: 18}}>
            <Image style={{ height: 30, width: 30,resizeMode: 'contain', }}
                source={require('../Images/User.png')}></Image>
                <Text style={{fontSize: 11, marginTop: 5}}>Profile</Text>
</View>
               </View>
               </TouchableOpacity>
            
  
  
            </View>
            </View>
    </View>

      </View>
      

      

     
      
    );
  }


  renderHorizontalItem = ({ item, index }) => {

    return (
  
  <View style={{
    flex:1, marginTop: 1,
    padding:1,
    borderRadius:10,
    paddingTop: 1,
    marginTop: 1,
    
    marginVertical:5,
    marginLeft: 18,
    marginRight: 18,
    // backgroundColor: 'red'
  
  }}>
  

  { index == 0 && <View>   
    
    <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Crescentek'}</Text>

<DropDownPicker
placeholder=""
        open={this.state.open}
        value={this.state.value}
        items={this.state.items}
        setOpen={this.setOpen}
        setValue={this.setValue0}
        setItems={this.setItems}
        containerProps={{
          height: this.state.open === true ? 220 : null,
          backgroundColor: "#fff",
        }}
        schema={{
          label: 'label1',
          value: 'value1'
        }}
      />

</View> }


  
         { index == 1 && <View>  
         
         <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Pratik Ghohs'}</Text> 

<TextInput
                    style={{
                      borderColor: '#4387bb',
                      borderWidth: 1,
                      width: '90%',
                      color: 'black',
                      height: 43,
                      borderRadius: 8,
                      paddingLeft: 8
                    }}
                    placeholder=""
                    ref ={ref => this.inputText1 = ref}
                    // editable={this.state.iseditablefname}
                    onChangeText={value => this.setState({
                      containerpurchase: value,
                    })}
                    value={this.state.containerpurchase}
                    keyboardType="default"></TextInput>

</View> }

{ index == 2 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Mobile No: '+ '+91 8768282890'}</Text> }

{ index == 3 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Email: '+ 'pratikghosh@crescentek.com'}</Text> }
            
            { index == 4 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Other Phone: '+ '033234 56765'}</Text> } 

{ index == 5 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'House No: '+ '156765'}</Text> } 

{ index == 6 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Street No: '+ 'M.G Road, Kolkata'}</Text> } 

     { index == 7 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Town: '+ 'Kolkata'}</Text> }   

{ index == 8 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Country '+ 'India'}</Text> } 
           
           { index == 9 && <Text style={{
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'ID: '+ 'SM015'}</Text> } 
  </View>
     )}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
     backgroundColor: "#ecf6fa",
    // backgroundColor: "#ecf6fa",
    marginTop: 0,
    zIndex: 0
  },
  textLabel: {
    fontFamily: 'BebasNeueProRegular',
    color: '#000',padding: 4, fontSize: 20, color: 'grey'
  },
  textInputField: {

  },
  dropDownContainerStyle:
  {

  },
  dropdownstyle:
  {

  },
  textInputFieldMultiline:
  {

  },
  mainView: {paddingTop: 1,
    marginTop: 20,
    
    marginVertical:5,
    marginLeft: 18,
    marginRight: 18,},

  dashboard_main_headers : {
    // backgroundColor: '#f55656',
    height: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 12,
  },
  dashboard_headers_Menu_View : {
    width: '50%',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  dashboard_headers_Create_View : {
    width: '50%',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  menu_icon: {
    width: 30,
    height: 30,
    marginStart: 10,
     marginTop: 4,
    backgroundColor: 'transparent',
    alignSelf: 'center',
    tintColor: '#4387bb',
    
  },
  create_icon: {
    width: 30,
    height: 30,
    marginEnd: 10,
     marginTop: 4,
    backgroundColor: 'transparent',
    alignSelf: 'center',
    tintColor: '#4387bb'
  },
  animatedBox: {
    flex: 1,
    backgroundColor: "#38C8EC",
    padding: 10
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F04812'
  },
  footer: {
    position: 'absolute',
    height: 80,
    left: 0, 
    // top: Dimensions.get('window').height - 100, 
    width: Dimensions.get('window').width,
    backgroundColor: 'white',
    bottom:0,
    // opacity: 0.9,

    borderTopWidth: 1,
    // borderRadius: 20,
    borderColor: 'white',
    borderBottomWidth: 0,
    shadowColor: 'white',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.9,
    shadowRadius: 20,
    elevation: 5,
    flexDirection: 'row',
          justifyContent: 'flex-start',
          alignContent: 'flex-start',
          alignItems: 'flex-start',
          shadowColor: 'grey',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 1,
        shadowRadius: 3,
  },
})