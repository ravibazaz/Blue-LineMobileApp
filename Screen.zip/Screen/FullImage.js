import React,{Component} from 'react';
import { ImageBackground,Dimensions, StyleSheet,Animated, FlatList,View,Text,Image, TouchableOpacity,Alert,ScrollView,SafeAreaView,Modal} from 'react-native';
import API from '../services/api';
import { PinchGestureHandler,State } from 'react-native-gesture-handler';
import ImageViewer from 'react-native-image-zoom-viewer';


const {width} =Dimensions.get("window");


export default class FullImage extends Component
{

     constructor(props)
     {
         super(props);
         this.state ={
              
               image:'',
               isModalVisible:true,
         };
     }



     componentDidMount()
     {
      const { navigation } = this.props;  
      this.setState({ image :navigation.getParam('Chart_image', 'NO-id')}); 
      console.log(navigation.getParam('Chart_image', 'NO-id')) ;
     
       
     }


     image =()=>
     {

     }

    
    //  scale = new Animated.Value(1);
     
    //  onZoomEventFunction = Animated.event(
    //      [
    //          {

    //             nativeEvent: {scale:this.scale}
    //          }
    //      ],
    //      {
    //          useNativeDriver:true // very imp
    //      }
    //  )
   
    //  onZoomStateChangeFunction = (event) =>{
    //      if(event.nativeEvent.oldState == State.ACTIVE){
    //          Animated.spring(this.scale,{
    //              toValue: 1,
    //              useNativeDriver: true //imp line

    //          }).start()
    //      }
    //  }





     render()
     {
        const images = [{ url: this.state.image }];
        const closeModal = () => { if (this.state.isModalVisible) { 
            this.setState({isModalVisible:false}) 
            this.props.navigation.navigate('Chartdetails')} }
         return(
       <View>
            


            
                 
                  {/* <ScrollView horizontal = {true}>
                 <PinchGestureHandler
            onGestureEvent = {this.onZoomEventFunction}
            onHandlerStateChange = {this.onZoomStateChangeFunction}>
            
             <Animated.Image style={{resizeMode:'contain',width: width,height:width,alignSelf:'center',transform:[{scale :this.scale}]}} source={{uri: this.state.image}}
               resizeMode= {'contain'}
               />
             
             </PinchGestureHandler>
             </ScrollView> */}
           
            <Modal transparent visible={this.state.isModalVisible} onRequestClose={closeModal}>
            {/* <SafeAreaView > */}
            
                <ImageViewer imageUrls={images}/>
                <TouchableOpacity style={{position: 'absolute', marginLeft:30, marginTop: 85}}
                  onPress={() => closeModal()}>
                <Image style={{resizeMode:'contain', width:30,height:30, tintColor: 'white'}} source = {require('../Images/arrow.png')}></Image>
                </TouchableOpacity>
                {/* </SafeAreaView > */}
            </Modal>
            </View>

           
            
            
         );
     }
 
 
 
 }
 
 var styles = StyleSheet.create({
     container: {
          flex: 1,
          width:null,
          height:null,
          backgroundColor: '#000000',
          justifyContent:'center',
          alignItems:"center"
     },
     boxarea : {
         marginRight: 20,
         marginLeft: 20,
        
         height:'30%',
        backgroundColor: '#fff',
         borderRadius: 10,
         borderWidth: 1,
         marginTop:20,
         color:'back'
     },    
     Imagearea : {
         marginRight: 20,
         marginLeft: 20,
        
         height:'55%',
        backgroundColor: '#fff',
         borderRadius: 10,
         borderWidth: 1,
         marginTop:20,
         color:'back'
 
     }, 
     
     
     item: {
         backgroundColor: '#D3D3D3',
         marginVertical: 8,
         marginHorizontal: 16,
         height: '30%',
         marginRight: 40,
         marginLeft: 40,
         marginTop:20,
       },
       title: {
         fontSize: 12,
       },
 
 })
 