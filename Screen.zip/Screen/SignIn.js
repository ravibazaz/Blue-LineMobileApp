import React,{Component, useState} from 'react';
import { View, Text, StyleSheet, AsyncStorage, FlatList, ScrollView, TouchableOpacity, Linking, SafeAreaView, TextInput, Image, Dimensions } from 'react-native'
import DropDownPicker from 'react-native-dropdown-picker';
import DatePicker from 'react-native-date-picker'
import AnimateLoadingButton from 'react-native-animate-loading-button';

export default class Profile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      

      modeDateTimePicker: 'time',
      userNameString: '',
      passwordString: ''
      
         

    };
   
  }
  _onPressBotton1Handler = async () => { 
    
    //       Keyboard.dismiss()
    //  this.Login()
    this.loadingButton.showLoading(true);
    this.Login()

    // this.props.navigation.navigate('LoginPage')
   
    
          }
          Login = async () => {
            
            AsyncStorage.setItem('token',  'yes');
            setTimeout(()=>{
              this.loadingButton.showLoading(false);
              this.props.navigation.replace('LoginPage') //ParcelDetailsPage //DashPage
          },2000)
          }

  render() {

   const { open, value, items } = this.state;

    return (
      
      <View style={styles.container}>
<SafeAreaView>
        
          </SafeAreaView>
          <ScrollView nestedScrollEnabled={true} horizontal={false}>
          <Text style={{fontFamily: 'BebasNeueProMiddle',fontSize: 38, marginTop: 85, color: 'dark', marginLeft: 33, marginBottom: 0}}>Welcome Back</Text>
          <Text style={{fontFamily: 'BebasNeueProMiddle', fontSize: 29, marginTop: 11, color: 'dark', marginLeft: 33, marginBottom: 85}}>Login into your account</Text>
          


          
          <TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                // width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8,
                marginLeft: 18,
                marginRight: 18,
                textAlignVertical: 'center',
                fontFamily: 'BebasNeueProRegular',
              }}
              textAlign={'center'}
              placeholder="User Name"
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                userNameString : value,
              })}
              value={this.state.userNameString}
              keyboardType='decimal-pad'></TextInput>
       
          
       <TextInput
              style={{
                borderColor: '#4387bb',
                borderWidth: 1,
                // width: '100%',
                color: 'black',
                height: 43,
                borderRadius: 8,
                paddingLeft: 8,
                marginLeft: 18,
                marginRight: 18,
                textAlignVertical: 'center',
                marginTop: 22,
                fontFamily: 'BebasNeueProRegular',
              }}
              textAlign={'center'}
              placeholder="Password"
              // ref ={ref => this.inputText1 = ref}
              // editable={this.state.iseditablefname}
              onChangeText={value => this.setState({
                passwordString : value,
              })}
              value={this.state.passwordString}
              keyboardType='decimal-pad'></TextInput>
        


        <View style={{
        flexDirection: "column",
        justifyContent: "center",
        paddingTop: 0,
        marginTop: 22,
        marginLeft: 18,
        marginRight: 18,
      }}>
              <AnimateLoadingButton
              ref={c => (this.loadingButton = c)}
              width={Dimensions.get('window').width - 36}
              height={43}
              fontFamily='BebasNeueProMiddle'
              title="Login"
              titleFontSize={21}
              titleColor="rgb(255,255,255)"
              backgroundColor="#4387bb"
              borderRadius={4}
              onPress={this._onPressBotton1Handler.bind(this)}
            />
          </View>


          </ScrollView>

          
          

      </View>
      

      

     
      
    );
  }



}

const styles = StyleSheet.create({
  container: {
    flex: 1,
     backgroundColor: "#ecf6fa",
    // backgroundColor: "#ecf6fa",
    marginTop: 0,
    zIndex: 0
  },
  textLabel: {
    fontFamily: 'BebasNeueProRegular',
    color: '#000',padding: 4, fontSize: 20, color: 'grey'
  },
  textInputField: {

  },
  dropDownContainerStyle:
  {

  },
  dropdownstyle:
  {

  },
  textInputFieldMultiline:
  {

  },
  mainView: {paddingTop: 1,
    marginTop: 20,
    
    marginVertical:5,
    marginLeft: 18,
    marginRight: 18,},

  dashboard_main_headers : {
    // backgroundColor: '#f55656',
    height: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 12,
  },
  dashboard_headers_Menu_View : {
    width: '50%',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  dashboard_headers_Create_View : {
    width: '50%',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  menu_icon: {
    width: 30,
    height: 30,
    marginStart: 10,
     marginTop: 4,
    backgroundColor: 'transparent',
    alignSelf: 'center',
    tintColor: '#4387bb',
    
  },
  create_icon: {
    width: 30,
    height: 30,
    marginEnd: 10,
     marginTop: 4,
    backgroundColor: 'transparent',
    alignSelf: 'center',
    tintColor: '#4387bb'
  },
  animatedBox: {
    flex: 1,
    backgroundColor: "#38C8EC",
    padding: 10
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F04812'
  },
  footer: {
    position: 'absolute',
    height: 80,
    left: 0, 
    // top: Dimensions.get('window').height - 100, 
    width: Dimensions.get('window').width,
    backgroundColor: 'white',
    bottom:0,
    // opacity: 0.9,

    borderTopWidth: 1,
    // borderRadius: 20,
    borderColor: 'white',
    borderBottomWidth: 0,
    shadowColor: 'white',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.9,
    shadowRadius: 20,
    elevation: 5,
    flexDirection: 'row',
          justifyContent: 'flex-start',
          alignContent: 'flex-start',
          alignItems: 'flex-start',
          shadowColor: 'grey',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 1,
        shadowRadius: 3,
  },
})