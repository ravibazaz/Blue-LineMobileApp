import React,{Component,useEffect} from "react";
import { ImageBackground, View,StyleSheet,SafeAreaView,ScrollView,Text } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import { WebView } from 'react-native-webview';


export default class HowToUse extends Component {

constructor(props)
{
   super(props);
   this.state = {
}

}
  
render()
{

  return(
   <WebView
   source={{ uri: 'https://infinite.red' }}
   style={{ marginTop: 0 }}
 />

  );

}


}

var styles = StyleSheet.create({


    container : {
       flex:1,
       width:null,
       height:null,
       resizeMode:'contain',
       color:'black'
    },
  
    borderline: {
        marginRight: 40,
        marginLeft: 40,
        marginTop: 30,
        height: 500,
        paddingTop: 20,
        paddingBottom: 20,
        backgroundColor: '#fff',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#black',
        color:'back'
      },
    
    

});

