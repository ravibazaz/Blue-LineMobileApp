import React,{Component, useEffect} from 'react';

import { StyleSheet, Image,ImageBackground, View,Text, Modal, ActivityIndicator,
   TextInput, TouchableOpacity, Dimensions, SafeAreaView, ScrollView, Alert, Linking,AsyncStorage} from 'react-native';

import {StatusBar} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import API from '../services/api';



export default class Login extends Component{

  constructor(props) {
    super(props);
    this.state = {
       

      EmailPhoneString: '',
      PasswordString: '',
      showPassword: true,
      isLoading: false,
countryCodeString : 'IN',
radioValueHaveDetails: 0,
placeholderString: 'Enter your pin',
emailkeyboardType: 'numbers-and-punctuation',
FcmTokenString: '',
progress: false,

 }

    

}




submit = async () => {

  let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
  
 
  var formdata = new FormData();

  

   console.log( this.state.EmailPhoneString);
   console.log(this.state.PasswordString);
   
  
 
   if (this.state.EmailPhoneString == '') {
    Alert.alert('Alert', 'Please Enter your email');
  } 
  else if (reg.test(this.state.EmailPhoneString.trim()) === false) {

    alert('Email is Not Correct');
    
  }
   else {
    // var logs = {
    //   user_id: user_id,
    //   kycfile_type: 'base64',
    //   kyc_file: this.state.selectedPANSource,
    //   pan_number: this.state.selectedPANNumber,
    //   address_proof_type: this.state.selectedID,
    //   address_proof_number: this.state.selectedKYCNumber,
    //   kyc_address_file: this.state.selectedIDSource,
    //   donee_type: this.state.selectedsecondValue,
    //   trust_certificate_file: this.state.selectedTrustFileSource,
    //   website_link: this.state.websiteLink,
    //   };

    this.setState({ progress: true})

      formdata.append('email_id', this.state.EmailPhoneString);
      
      // formdata.append('password', this.state.PasswordString);
    
  


    var response = await API.postWithFormData('forget-password', formdata);

    if (response.status == 'success') {
    
      // need to add kyc uploadation function here
     
     
      // try {
      //   await AsyncStorage.setItem(
      //     'status',
      //     'true'
      //   );
      //   await AsyncStorage.setItem(
      //     'username',
      //     response.data.fullname
      //   );
      //   await AsyncStorage.setItem(
      //     'email',
      //     response.data.username
      //   );
      //   await AsyncStorage.setItem(
      //     'userid',
      //     response.data.userid
      //   );
      // } catch (error) {
      //   // Error saving data
      // }

      this.setState({ progress: false})

      Alert.alert(
        'Success',
        response.message, // <- this part is optional, you can pass an empty string
        [
          //  {text: 'NO', onPress: () => console.log('No')}, //logout()
          {text: 'Go Back', onPress: () => this.props.navigation.goBack()}, 
          // {text: 'Cancel', onPress: () => console.log('Clicked on Cancel Button')}, 
        ],
        {cancelable: false},
      )


      
      // this.props.navigation.navigate('UsesPage')
      
    } else {
      this.setState({ progress: false})
      Alert.alert(response.status, response.message);
    }
  }
};




 
  render(){

    const { navigate } = this.props.navigation;


    return(
<ImageBackground style={styles.MainContainer1}
        source={require('../Images/bg.jpg')}>
<SafeAreaView >
<ScrollView >

<View style={{
    flex: 1,
    justifyContent: 'center',
    alignItems: 'stretch',
    marginTop: 35
  }}>
<Image style={{ height: 120,borderRadius:2,width: 200, justifyContent: "space-around",    //  <-- you can use "center", "flex-start",
    resizeMode: "contain", alignSelf: 'center', 
}}
source={require('../Images/logo.png')}>
</Image> 
</View>  




<Text style={{color: 'black',fontSize:16, marginTop: 70, marginLeft: 33}}></Text>
<View style={styles.itemRow1}>
                 
                  <View style={{marginLeft: 26, marginTop:15, bottom:7, marginRight: 7}}>
                 
       </View> 
       
        <TextInput style={styles.textInput2}
                
                placeholder='Enter Email ID'
                placeholderTextColor={'grey'}
                value = {this.state.EmailPhoneString}
              
                autoCapitalize = 'none'
              
                onChangeText={(text) => this.setState({ EmailPhoneString: text})}></TextInput>
       
        </View>
                

               

<View style={{marginLeft:26,marginTop:-4, backgroundColor: 'gray', marginRight: 26, height: 1, marginBottom: 7}}></View>


<Text style={{
      fontSize:17,
      color:'black',
      alignSelf:'center',
      marginTop:10,
      padding: 7
  }}>Please enter your email address and we will send you a link to reset the password.</Text>

                
               <TouchableOpacity style={{marginRight:100,marginLeft:100,marginTop:30}} onPress ={() => this.submit()  }>
                <LinearGradient start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={{height:60, borderRadius:30}}
                colors={['#07afd6', '#6bc081']}>
                    <Text style={{fontSize:20,fontWeight: "200",alignSelf:'center',color:'white',
                marginTop:16}}>Submit</Text>        
        </LinearGradient> 
        </TouchableOpacity>
               


       
        <View style={{
    flex: 1,
    justifyContent: 'center',
    alignItems: 'stretch',
    marginTop: 17
  }}>

</View> 
        

           </ScrollView>

           <Modal
            transparent={true}
            animationType={'none'}
            visible={this.state.progress}
            onRequestClose={() => {console.log('close modal')}}>
            <View style={{
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'space-around',
        backgroundColor: '#00000040'
    }}>
                <View style={{
        backgroundColor: '#FFFFFF',
        height: 100,
        width: 100,
        borderRadius: 10,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    }}>
                    <ActivityIndicator color="#999999" size="large"
                        animating={this.state.progress} />
                        {/* <Text style={{color: 'black',fontSize:16, marginTop: 20, alignSelf: 'center'}}>Loading...</Text> */}
                </View>
            </View>
        </Modal>

            </SafeAreaView >
            </ImageBackground>
    );
  }

 
  
 

  //   if (this.state.EmailPhoneString.trim() == '') {
  //       alert('Please Enter Email or Phone Number');
  //   }
  //   else if (this.state.PasswordString.trim() == '') {
  //       alert('Please Enter Password');
  //   }
  //   else {


  //   if (this.state.radioValueHaveDetails == 0)
  //   {
  //     let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
  // if (reg.test(this.state.EmailPhoneString.trim()) === false) {

  //   alert('Provided Email is Not Correct');
    
  // }
  // else
  // {
  //   this.loadingButton1.showLoading(true);
  //     this.customLoginClick()
  // }
  //   }
  //   else
  //   {
  //     this.loadingButton1.showLoading(true);
  //     this.customLoginClick()
  //   }

  //  }
  
}


 

  

  
 

// localNotification = async () => {
//   //required for Android
//   const channel = new Android.Channel(
//     "test-channel",
//     "Test Channel",
//     Android.Importance.Max
//   ).setDescription("My apps test channel")

//   // for android create the channel
//   notifications.android().createChannel(channel)
//   await notifications.displayNotification(
//     new NotificationMessage()
//       .setNotificationId("notification-id")
//       .setTitle("Notification title")
//       .setBody("Notification body")
//       .setData({
//         key1: "key1",
//         key2: "key2",
//       })
//       .android.setChannelId("test-channel") //required for android
//   )
// }


  


var styles = StyleSheet.create({
    container: {
      flex: 1,
      // remove width and height to override fixed static size
      width: null,
      height: null,
      resizeMode:'contain'
    },
    MainContainer:{
        width:null,
        height:null,
        backgroundColor: 'white',
    },
    SubContainer:
    {
        marginLeft: 20,
        marginTop: -25,
        width:Dimensions.get('window').width - 40,
        height:Dimensions.get('window').height - 210,
        backgroundColor: 'rgba(246, 244, 243, 1)',
        shadowColor: 'grey',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 1,
      shadowRadius: 3,
     },
    login:{
        fontSize:22,
        color:'black',
        alignSelf:'center',
        marginTop:20,
    },
    SigninToContinue:
    {
        fontSize:17,
        color:'grey',
        alignSelf:'center',
        marginTop:10,
    },

    textInput:{
    // borderBottomWidth: 1,
    // borderBottomColor: 'grey',
    width: null,
    marginTop:35,
    marginLeft: 9,
    borderRadius: 0,
    marginLeft: 0,
    marginRight: 0,
    backgroundColor: 'white',
    fontSize: 16,
    paddingLeft: 13,
    height: 40,
    backgroundColor: 'rgba(246, 244, 243, 1)'
    
    },
    textInput2:{
      // borderBottomWidth: 1,
      // borderBottomColor: 'grey',
      width: '80%',
      marginTop:3,
      marginLeft: 2,
      borderRadius: 0,
      marginLeft: 0,
      marginRight: 26,
      color:'black',
      // backgroundColor: 'null',
      fontSize: 16,
      paddingLeft: 0,
      height: 40,
      // backgroundColor: 'rgba(246, 244, 243, 1)',
     // backgroundColor: 'red'
      
      },
    textPass:{
        // borderBottomWidth: 1,
        // borderBottomColor: 'grey',
        width: null,
        marginTop:3,
        borderRadius: 0,
        marginLeft: 26,
        marginRight: 26,
        // backgroundColor: 'white',
        fontSize: 16,
        height: 40,
        paddingLeft: 0,
        
        },
        lineStyle:{
            height:1,
            width:140,
            backgroundColor:'#1F203E',
            marginLeft:50,
            alignSelf:'center'
        },
        lineSecond:{
            height:1,
            width:140,
            backgroundColor:'#1F203E',
            alignSelf:'center',
            marginTop:2
        },
        itemRow:{
          marginTop: 14,
          flexDirection: 'row',
        justifyContent: 'flex-start',
        alignContent: 'flex-start',
        alignItems: 'flex-start',
        width: '100%',
       
        },
        itemRow1:{
          marginTop: 0,
          flexDirection: 'row',
        justifyContent: 'flex-start',
        alignContent: 'flex-start',
        alignItems: 'flex-start',
        width: '100%',
       
        },
        MainContainer1: {
          flex: 1,
          // remove width and height to override fixed static size
          width: null,
          height: null,
        },
  });
//   export async function fetchWithTimeout(url, options, timeout = 5000) {
//     return Promise.race([
//         fetch(url, options),
//         new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), timeout))
//     ]);
// }