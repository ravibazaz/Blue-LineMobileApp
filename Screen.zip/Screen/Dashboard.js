import React,{Component, useEffect} from 'react';

import { StyleSheet, Modal, Image,ImageBackground, View,Text, TextInput, TouchableOpacity, Dimensions, SafeAreaView, ScrollView, Alert, Linking,AsyncStorage} from 'react-native';

import {StatusBar} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import API from '../services/api';



export default class Dashboard extends Component{

  constructor(props) {
    super(props);
    this.state = {
    username :'',
    email:'',
    modalVisibleForDelete: false,
    DescriptionString: '',
    maxLengthh1: 5000       

 }
}

async componentDidMount ()
  {

 
   this.setState({
      username : await AsyncStorage.getItem('username'),
      email : await AsyncStorage.getItem('email'),
      userid: await AsyncStorage.getItem('userid')
   })
   

  }


logout = async () =>
{

  this.conformLogout()

  // Alert.alert(
  //   'Alert',
  //   'Are you sure you want to logout?', // <- this part is optional, you can pass an empty string
  //   [
  //     //  {text: 'NO', onPress: () => console.log('No')}, //logout()
  //     {text: 'OK', onPress: () => this.conformLogout()}, 
  //     {text: 'Cancel', onPress: () => console.log('Clicked on Cancel Button')}, 
  //   ],
  //   {cancelable: false},
  // )
 
}

conformLogout = async () =>
{
  try {
    await AsyncStorage.setItem(
      'status',
      'false'
    );
 
    await AsyncStorage.setItem(
      'username',
      ''
    );
    await AsyncStorage.setItem(
     'email',
     ''
   );
  } catch (error) {
    // Error saving data
  }
  this.props.navigation.replace('LoginPage'); 
}

deleteAccount = async () =>
{

  console.log('delete account pressed')
  this.setState({ modalVisibleForDelete : true}); 
 
}
 deleteRequestSend = async () => {

if (this.state.DescriptionString.trim().length == 0)
{
  Alert.alert(
    'Warning',
    'Please enter reason that you want to delete your account?', // <- this part is optional, you can pass an empty string
    [
      //  {text: 'NO', onPress: () => console.log('No')}, //logout()
      {text: 'OK', onPress: () => console.log('enter notes')}, 
      
    ],
    {cancelable: false},
  )
}
else
{
  console.log('deleteRequestSend .....');

    var user_id = await AsyncStorage.getItem('user_id');
  var logs = {
    user_id: this.state.userid,//user_id,
    remarks: this.state.DescriptionString
  };
  console.log(logs);
  var response = await API.post('account-delete', logs);
  if (response.status == 'success') {
    // logout()
    
    Alert.alert(
      'Success',
      response.message, // <- this part is optional, you can pass an empty string
      [
        //  {text: 'NO', onPress: () => console.log('No')}, //logout()
        {text: 'OK', onPress: () => this.logout()}, 
        
      ],
      {cancelable: false},
    )
      
      
   
  } else {
    Alert.alert(response.status, response.message);
  }
}



};
 remarksTyping = async (text) => {
 
  this.setState({ DescriptionString : text, maxLengthh1: 5000 - text.length}); 
}
  render(){

    const { navigate } = this.props.navigation;


    return(
<ImageBackground style={styles.MainContainer1}
        source={require('../Images/bg.jpg')}>
<SafeAreaView >
<ScrollView >
<View style={{
    //  backgroundColor: '#f55656',
    // height: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 12,
    alignItems:"center"
  }}>

<TouchableOpacity style={{paddingTop:10,alignSelf:'flex-start',marginLeft:15,}}  onPress={this.deleteAccount}><Text style={{fontWeight: 'bold' }}>Delete Account</Text>
 </TouchableOpacity> 

<TouchableOpacity  onPress={this.logout}><Image style={{margingTop:10,resizeMode:'contain',width:30,height:40,alignSelf:'flex-end',marginRight:15}} source = {require('../Images/logout.png')}></Image>
 </TouchableOpacity> 
</View>
<View style={{
    flex: 1,
    justifyContent: 'center',
    alignItems: 'stretch',
    marginTop: 5
  }}>
<Image style={{ height: 100,borderRadius:2,width: 100, justifyContent: "space-around",    //  <-- you can use "center", "flex-start",
    resizeMode: "contain", alignSelf: 'center', 
}}
source={require('../Images/logo.png')}>
</Image> 
</View> 

<Text style={{color: 'black',fontSize:15,fontWeight:'700',  justifyContent:'center',alignSelf:'center'}}>{this.state.username}</Text>
<Text style={{color: 'black',fontSize:15, fontWeight:'700',alignSelf:'center'}}>{this.state.email}</Text>



<View>
        <TouchableOpacity style = {{marginTop:60, marginBottom:10,marginLeft:10,marginRight:10}} onPress ={() => this.props.navigation.navigate('Chartlist')}>
              <LinearGradient start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={{height:70, borderRadius:10}}
              colors={['#FAA0A0','#ffff','#FAA0A0']}>
                 <View style={{flexDirection:'row'}}>
                  <Image style={{resizeMode:'contain',width:70,height:60,marginLeft:60}} source = {require('../Images/icon1.png')}></Image>
                  <Text style={{fontSize:20,fontWeight: "200",alignSelf:'center',color:'black',fontWeight:'500',padding:5,
              marginTop:9}}>Chart</Text>  
              </View>      
      </LinearGradient> 
      </TouchableOpacity>
    
  </View>
  <View>
        <TouchableOpacity style = {{marginTop:10, marginBottom:10,marginLeft:10,marginRight:10}} onPress ={() => this.props.navigation.navigate('SubList')}>
              <LinearGradient start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={{height:70, borderRadius:10}}
              colors={['#AFE1AF','#ffff','#AFE1AF']}>
                <View style={{flexDirection:'row'}}>
                  <Image style={{resizeMode:'contain',width:70,height:60,alignSelf:'center', marginLeft:60}} source = {require('../Images/icon2.png')}></Image>
                  <Text style={{fontSize:20,fontWeight: "200",alignSelf:'center',color:'black',fontWeight:'500',padding:5,
              marginTop:9}}>Regional Disease</Text>   
              </View>     
      </LinearGradient> 
      </TouchableOpacity>
    
  </View>
  <View>
        <TouchableOpacity style = {{marginTop:10, marginBottom:10,marginLeft:10,marginRight:10}} onPress ={() => this.props.navigation.navigate('HomePage')}>
              <LinearGradient start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={{height:70, borderRadius:10}}
              colors={['#CCCCFF','#ffff','#CCCCFF']}>
                 <View style={{flexDirection:'row'}}>
                  <Image style={{resizeMode:'contain',width:70,height:60,alignSelf:'center',marginLeft:60}} source = {require('../Images/icon3.png')}></Image>
                  <Text style={{fontSize:20,fontWeight: "200",alignSelf:'center',color:'black',fontWeight:'500',padding:5,
              marginTop:9}}>Category</Text> 
              </View>       
      </LinearGradient> 
      </TouchableOpacity>
    
  </View>

             </ScrollView>

            </SafeAreaView >

            <Modal
                            animationType="slide"
                            transparent={false}
                            visible={this.state.modalVisibleForDelete}
                        >
                          
                            <View style={{ height: 300, marginTop: 105, backgroundColor: 'white',  width: 340,
        alignSelf: 'center', }}>
                            
                                <View style={{
        height: 240,
        width: 340,
        alignSelf: 'center',
        marginTop: 0,
        backgroundColor: 'white',//'#0da2c3',
        borderRadius: 6,
        borderColor:'black',
        borderWidth:1,
    }}>
<Text style={{ fontSize: 13, alignSelf: 'flex-start', marginTop: 10, color: 'black', marginLeft: 17, marginBottom: 7, fontWeight: 'bold' }}>Reason For Deleting Your Account ?</Text>
<TextInput style={{
    
    width: null,
    marginLeft: 17,
    borderRadius: 0,
    marginRight: 17,
    backgroundColor: 'white',
    fontSize: 12,
    height: 80,
    color: 'gray',
   borderColor: 'black',
   borderWidth: 1,
      padding: 5,
      paddingTop: 5,
      
    
    }}
                placeholder={'Enter remarks here...'}
                multiline={true}
     numberOfLines={5}
     textAlignVertical={'top'}
                placeholderTextColor={'grey'}
                value = {this.state.DescriptionString}
                maxLength={5000}
                onChangeText={(text) => this.remarksTyping(text)}
                ></TextInput>
<Text style={{ fontSize: 11, alignSelf: 'flex-start', marginTop: 5, color: '#f55656', marginLeft: 17, marginBottom: 7, fontWeight: '400' }}>{this.state.maxLengthh1+' Character remaining'}</Text>
<TouchableOpacity style={{marginRight:50,marginLeft:50,marginTop:30}} onPress ={() => this.deleteRequestSend()}>
             
<LinearGradient start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={{height:60, borderRadius:14}}
                colors={['#07afd6', '#07afd6']}>
                    <Text style={{fontSize:20,fontWeight: "600",alignSelf:'center',color:'white',
                marginTop:16}}>Submit</Text>        
        </LinearGradient>
</TouchableOpacity>


                                </View>

                                <TouchableOpacity onPress={() => { this.setState({ modalVisibleForDelete :false}) }}>
                                    <View style={{
        height: 45,
        marginTop: 7,
        backgroundColor: 'white',//'#0da2c3',
        width: 340,
        alignSelf: 'center',
        borderRadius: 6,
        borderColor:'black',
        borderWidth:1,
    }}>
                                        <Text style={{ fontSize: 20, alignSelf: 'center', marginTop: 10, color: 'black' }}>Cancel</Text>
                                    </View>
                                </TouchableOpacity>
                                </View>
                            
                        </Modal>

            </ImageBackground>
    );
  }

 
  
 

  //   if (this.state.EmailPhoneString.trim() == '') {
  //       alert('Please Enter Email or Phone Number');
  //   }
  //   else if (this.state.PasswordString.trim() == '') {
  //       alert('Please Enter Password');
  //   }
  //   else {


  //   if (this.state.radioValueHaveDetails == 0)
  //   {
  //     let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
  // if (reg.test(this.state.EmailPhoneString.trim()) === false) {

  //   alert('Provided Email is Not Correct');
    
  // }
  // else
  // {
  //   this.loadingButton1.showLoading(true);
  //     this.customLoginClick()
  // }
  //   }
  //   else
  //   {
  //     this.loadingButton1.showLoading(true);
  //     this.customLoginClick()
  //   }

  //  }
  
}


 

  

  
 

// localNotification = async () => {
//   //required for Android
//   const channel = new Android.Channel(
//     "test-channel",
//     "Test Channel",
//     Android.Importance.Max
//   ).setDescription("My apps test channel")

//   // for android create the channel
//   notifications.android().createChannel(channel)
//   await notifications.displayNotification(
//     new NotificationMessage()
//       .setNotificationId("notification-id")
//       .setTitle("Notification title")
//       .setBody("Notification body")
//       .setData({
//         key1: "key1",
//         key2: "key2",
//       })
//       .android.setChannelId("test-channel") //required for android
//   )
// }


  


var styles = StyleSheet.create({
    container: {
      flex: 1,
      // remove width and height to override fixed static size
      width: null,
      height: null,
      resizeMode:'contain'
    },
    MainContainer:{
        width:null,
        height:null,
        backgroundColor: 'white',
    },
    SubContainer:
    {
        marginLeft: 20,
        marginTop: -25,
        width:Dimensions.get('window').width - 40,
        height:Dimensions.get('window').height - 210,
        backgroundColor: 'rgba(246, 244, 243, 1)',
        shadowColor: 'grey',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 1,
      shadowRadius: 3,
     },
    login:{
        fontSize:22,
        color:'black',
        alignSelf:'center',
        marginTop:20,
    },
    SigninToContinue:
    {
        fontSize:17,
        color:'grey',
        alignSelf:'center',
        marginTop:10,
    },

    textInput:{
    // borderBottomWidth: 1,
    // borderBottomColor: 'grey',
    width: null,
    marginTop:35,
    marginLeft: 9,
    borderRadius: 0,
    marginLeft: 0,
    marginRight: 0,
    backgroundColor: 'white',
    fontSize: 16,
    paddingLeft: 13,
    height: 40,
    backgroundColor: 'rgba(246, 244, 243, 1)'
    
    },
    textInput2:{
      // borderBottomWidth: 1,
      // borderBottomColor: 'grey',
      width: '80%',
      marginTop:3,
      marginLeft: 2,
      borderRadius: 0,
      marginLeft: 0,
      marginRight: 26,
      color:'black',
      // backgroundColor: 'null',
      fontSize: 16,
      paddingLeft: 0,
      height: 40,
      // backgroundColor: 'rgba(246, 244, 243, 1)',
     // backgroundColor: 'red'
      
      },
    textPass:{
        // borderBottomWidth: 1,
        // borderBottomColor: 'grey',
        width: null,
        marginTop:3,
        borderRadius: 0,
        marginLeft: 26,
        marginRight: 26,
        // backgroundColor: 'white',
        fontSize: 16,
        height: 40,
        paddingLeft: 0,
        
        },
        lineStyle:{
            height:1,
            width:140,
            backgroundColor:'#1F203E',
            marginLeft:50,
            alignSelf:'center'
        },
        lineSecond:{
            height:1,
            width:140,
            backgroundColor:'#1F203E',
            alignSelf:'center',
            marginTop:2
        },
        itemRow:{
          marginTop: 14,
          flexDirection: 'row',
        justifyContent: 'flex-start',
        alignContent: 'flex-start',
        alignItems: 'flex-start',
        width: '100%',
       
        },
        itemRow1:{
          marginTop: 0,
          flexDirection: 'row',
        justifyContent: 'flex-start',
        alignContent: 'flex-start',
        alignItems: 'flex-start',
        width: '100%',
       
        },
        MainContainer1: {
          flex: 1,
          // remove width and height to override fixed static size
          width: null,
          height: null,
        },
  });
 