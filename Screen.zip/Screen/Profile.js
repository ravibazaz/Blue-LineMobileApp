import React,{Component, useEffect} from 'react';
import { View, Text, StyleSheet, FlatList, ScrollView, TouchableOpacity, SafeAreaView, Image, Dimensions } from 'react-native'

export default class Profile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      itemList:  [
        {a: 'London To Paris', b: '102',  c: '23.12.2022', d: 'Available Stock: 45'}, 
        {a: 'Manchester United to Paris', b: '107',  c: '24.12.2022', d: 'Available Stock: 100'},
        {a: 'India To Paris', b: '311',  c: '25.12.2022', d: 'Available Stock: 134'},
        {a: 'ALPS', b: '102',  c: '26.12.2022', d: 'Available Stock: 45'}, 
        {a: 'ALPS', b: '107',  c: '27.12.2022', d: 'Available Stock: 100'},
        {a: 'ALPS', b: '311',  c: '28.12.2022', d: 'Available Stock: 134'},
        {a: 'ALPS', b: '102',  c: '29.12.2022', d: 'Available Stock: 45'}, 
        {a: 'ALPS', b: '107',  c: '30.12.2022', d: 'Available Stock: 100'},
        {a: 'ALPS', b: '311',  c: '31.12.2022', d: 'Available Stock: 134'},
        {a: 'ALPS', b: '107',  c: '12.12.2022', d: 'Available Stock: 100'},
        ]
    };
  }

 

  render() {
    return (
      
      <View style={styles.container}>
<SafeAreaView>
        {/* <View style={styles.dashboard_main_headers}>
            <View style={styles.dashboard_headers_Menu_View}>
              <TouchableOpacity
              
                onPress={() => this.props.navigation.openDrawer()}>
                <Image
                  style={styles.menu_icon}
                  source={require('../Images/outline_apps_black_48.png')}
                />
              </TouchableOpacity>
            
            </View>
            <View style={styles.dashboard_headers_Create_View}>
              <TouchableOpacity
                onPress={() => this.props.navigation.navigate('Search_screen')}>
                <Image
                  style={styles.create_icon}
                  source={require('../Images/outline_add_black_48.png')}
                  // resizeMode="contain"dashboard_main_btn
                />
              </TouchableOpacity>
              </View>

          </View> */}
          </SafeAreaView>
          <ScrollView>
          <Text style={{fontFamily: 'BebasNeueProMiddle',fontSize: 34, marginTop: 45, color: '#4387bb', marginLeft: 33, marginBottom: 8}}>Profile</Text>

          

          <FlatList
     keyboardDismissMode="none"
      keyboardShouldPersistTaps='handled'
      style={{
        marginTop: 6,
        marginBottom: 72
      }}
      
                        data={this.state.itemList}
                        renderItem={this.renderHorizontalItem}
                        keyExtractor={(item, index) => index}
                    /> 

          </ScrollView>


          <View style={styles.footer}>
      <View style={{flexDirection:'row', alignItems: 'center', justifyContent: 'center'}}>
            <View style={{flex:1, maxWidth: 414, backgroundColor: null, flexDirection:'row', justifyContent:'space-between'}}>
              
            <TouchableOpacity onPress ={() => this.props.navigation.navigate('LoginPage')}>
            <View style={{ marginLeft: 0, width: Dimensions.get('window').width/3, marginTop: 0, height: 80, backgroundColor: 'null'}}>
            <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'flex-start', marginStart: 18}}>
            <Image style={{ height: 30, width: 30,resizeMode: 'contain', }}
                source={require('../Images/Home.png')}></Image>
                <Text style={{fontFamily: 'BebasNeueProMiddle',fontSize: 11, marginTop: 5}}>Home</Text>
</View>

            
             </View>
             </TouchableOpacity>

             <TouchableOpacity onPress ={() => this.props.navigation.navigate('NewOrderPage')}>
                 

            <View style={{ marginLeft: 0, width: Dimensions.get('window').width/3, marginTop: 0, height: 80}}>
            <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'center'}}>
            <Image style={{ height: 30, width: 30,resizeMode: 'contain'}}
                source={require('../Images/Create.png')}></Image>
                <Text style={{fontFamily: 'BebasNeueProMiddle',fontSize: 11, marginTop: 5}}>New Booking</Text>
</View>
               </View>
            
            </TouchableOpacity>

               
                 

            <View style={{ marginLeft: 0, width: Dimensions.get('window').width/3, marginTop: 0, height: 80}}>
            <View style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'flex-end', marginEnd: 18}}>
            <Image style={{ height: 30, width: 30,resizeMode: 'contain', tintColor: 'grey'}}
                source={require('../Images/User.png')}></Image>
                <Text style={{fontFamily: 'BebasNeueProMiddle',fontSize: 11, marginTop: 5}}>Profile</Text>
</View>
               </View>
            
            
  
  
            </View>
            </View>
    </View>

      </View>
      

      

     
      
    );
  }
  renderHorizontalItem = ({ item, index }) => {

    return (
  
  <View style={{
    flex:1, marginTop: 1, backgroundColor:'#fff',
    padding:1,
    borderRadius:10,
    paddingTop: 1,
    shadowColor: '#efefef',
    shadowOffset: { width: 0, height: 23 },
    shadowOpacity: 1,
    shadowRadius: 3,
    marginTop: 1,
    elevation: 3,
    marginVertical:5,
    marginLeft: 18,
    marginRight: 18,
    borderColor: '#198ccd',
    borderWidth: 1,
    height: 50,
    alignContent:'center',
    alignItems: 'flex-start',
    justifyContent: 'center',

     backgroundColor: 'transparent'
  
  }}>
  
           
  
         { index == 0 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Name: '+ 'Pratik Ghohs'}</Text> }

{ index == 1 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Company Name: '+ 'Crescentek'}</Text> }

{ index == 2 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Mobile No: '+ '+91 8768282890'}</Text> }

{ index == 3 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Email: '+ 'pratikghosh@crescentek.com'}</Text> }
            
            { index == 4 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Other Phone: '+ '033234 56765'}</Text> } 

{ index == 5 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'House No: '+ '156765'}</Text> } 

{ index == 6 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Street No: '+ 'M.G Road, Kolkata'}</Text> } 

     { index == 7 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Town: '+ 'Kolkata'}</Text> }   

{ index == 8 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'Country '+ 'India'}</Text> } 
           
           { index == 9 && <Text style={{fontFamily: 'BebasNeueProRegular',
  color: '#000',padding: 4, fontSize: 20, color: 'grey'
}}>{'ID: '+ 'SM015'}</Text> } 
  </View>
     )}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
     backgroundColor: "#ecf6fa",
    // backgroundColor: "#ecf6fa",
    marginTop: 0,
    zIndex: 0
  },
  dashboard_main_headers : {
    // backgroundColor: '#f55656',
    height: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 12,
  },
  dashboard_headers_Menu_View : {
    width: '50%',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  dashboard_headers_Create_View : {
    width: '50%',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  menu_icon: {
    width: 30,
    height: 30,
    marginStart: 10,
     marginTop: 4,
    backgroundColor: 'transparent',
    alignSelf: 'center',
    tintColor: '#4387bb',
    
  },
  create_icon: {
    width: 30,
    height: 30,
    marginEnd: 10,
     marginTop: 4,
    backgroundColor: 'transparent',
    alignSelf: 'center',
    tintColor: '#4387bb'
  },
  animatedBox: {
    flex: 1,
    backgroundColor: "#38C8EC",
    padding: 10
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F04812'
  },
  footer: {
    position: 'absolute',
    height: 80,
    left: 0, 
    // top: Dimensions.get('window').height - 100, 
    width: Dimensions.get('window').width,
    backgroundColor: 'white',
    bottom:0,
    // opacity: 0.9,

    borderTopWidth: 1,
    // borderRadius: 20,
    borderColor: 'white',
    borderBottomWidth: 0,
    shadowColor: 'white',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.9,
    shadowRadius: 20,
    elevation: 5,
    flexDirection: 'row',
          justifyContent: 'flex-start',
          alignContent: 'flex-start',
          alignItems: 'flex-start',
          shadowColor: 'grey',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 1,
        shadowRadius: 3,
  },
})